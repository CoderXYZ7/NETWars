/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.danieletoniolo.poligoni;

/**
 * Square implementation of the PolygonInt interface
 * Represents a square with equal sides and calculates its area and perimeter
 * 
 * @author user1
 */
public class Square implements PolygonInt {
    // Length of the square's side
    private int side;
    
    /**
     * Constructor: creates a square with the specified side length
     * @param side The length of each side of the square
     */
    public Square(int side) {
        this.side = side;
    }
    
    /**
     * Calculates the area of the square using side^2
     * @return The area of the square
     */
    @Override
    public int getArea() {
        return side * side;
    }
    
    /**
     * Calculates the perimeter of the square using 4 × side
     * @return The perimeter of the square
     */
    @Override
    public int getPerimeter() {
        return 4 * side;
    }
    
    /**
     * Returns the type of the polygon
     * @return String "Square"
     */
    @Override
    public String returnPolygon() {
        return "Square";
    }
}
