/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.danieletoniolo.poligoni;

/**
 * Triangle implementation of the PolygonInt interface
 * Represents a triangle with base, height, and sides, and calculates its area and perimeter
 */
public class Triangle implements PolygonInt {
    // Triangle dimensions
    private int base;
    private int height;
    private int side1;
    private int side2;
    
    /**
     * Constructor: creates a triangle with specified dimensions
     * @param base The base length of the triangle
     * @param height The height of the triangle
     * @param side1 Length of first side
     * @param side2 Length of second side
     */
    public Triangle(int base, int height, int side1, int side2) {
        this.base = base;
        this.height = height;
        this.side1 = side1;
        this.side2 = side2;
    }
    
    /**
     * Calculates the area of the triangle using (base x height) / 2
     * @return The area of the triangle
     */
    @Override
    public int getArea() {
        return (base * height) / 2;
    }
    
    /**
     * Calculates the perimeter of the triangle by adding all sides
     * @return The perimeter of the triangle
     */
    @Override
    public int getPerimeter() {
        return base + side1 + side2;
    }
    
    /**
     * Returns the type of the polygon
     * @return String "Triangle"
     */
    @Override
    public String returnPolygon() {
        return "Triangle";
    }
}
