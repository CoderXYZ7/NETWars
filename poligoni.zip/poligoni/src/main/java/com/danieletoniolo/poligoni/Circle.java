/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.danieletoniolo.poligoni;

/**
 * Circle implementation of the PolygonInt interface
 * Represents a circle with a given radius and calculates its area and perimeter
 */
public class Circle implements PolygonInt {
    // Radius of the circle
    private int radius;
    
    /**
     * Constructor: creates a circle with the specified radius
     * @param radius The radius of the circle
     */
    public Circle(int radius) {
        this.radius = radius;
    }
    
    /**
     * Calculates the area of the circle using πr²
     * @return The area of the circle (rounded to integer)
     */
    @Override
    public int getArea() {
        return (int) (Math.PI * radius * radius);
    }
    
    /**
     * Calculates the perimeter (circumference) of the circle using 2πr
     * @return The perimeter of the circle (rounded to integer)
     */
    @Override
    public int getPerimeter() {
        return (int) (2 * Math.PI * radius);
    }
    
    /**
     * Returns the type of the polygon
     * @return String "Circle"
     */
    @Override
    public String returnPolygon() {
        return "Circle";
    }
}
