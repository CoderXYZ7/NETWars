/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.danieletoniolo.poligoni;

/**
 * Rectangle implementation of the PolygonInt interface
 * Represents a rectangle with width and height and calculates its area and perimeter
 */
public class Rectangle implements PolygonInt {
    // Width and height of the rectangle
    private int width;
    private int height;
    
    /**
     * Constructor: creates a rectangle with specified width and height
     * @param width The width of the rectangle
     * @param height The height of the rectangle
     */
    public Rectangle(int width, int height) {
        this.width = width;
        this.height = height;
    }
    
    /**
     * Calculates the area of the rectangle using width × height
     * @return The area of the rectangle
     */
    @Override
    public int getArea() {
        return width * height;
    }
    
    /**
     * Calculates the perimeter of the rectangle using 2(width + height)
     * @return The perimeter of the rectangle
     */
    @Override
    public int getPerimeter() {
        return 2 * (width + height);
    }
    
    /**
     * Returns the type of the polygon
     * @return String "Rectangle"
     */
    @Override
    public String returnPolygon() {
        return "Rectangle";
    }
}
