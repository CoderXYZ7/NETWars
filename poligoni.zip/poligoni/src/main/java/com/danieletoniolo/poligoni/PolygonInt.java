/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.danieletoniolo.poligoni;

/**
 *
 * @author user1
 */
public interface PolygonInt {
    
    int getArea();
    int getPerimeter();
    String returnPolygon();
    
}
