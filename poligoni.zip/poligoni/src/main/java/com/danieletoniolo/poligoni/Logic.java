/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.danieletoniolo.poligoni;

import java.util.ArrayList;
import java.util.List;

/**
 * Core logic class that manages polygon instances and calculations
 * Maintains lists of different polygon types and handles area/perimeter calculations
 */
public class Logic {
    // Lists to store different types of polygons
    private List<PolygonInt> circles;
    private List<PolygonInt> squares;
    private List<PolygonInt> rectangles;
    private List<PolygonInt> triangles;
    
    /**
     * Constructor: initializes polygon lists and creates sample instances
     */
    public Logic() {
        circles = new ArrayList<>();
        squares = new ArrayList<>();
        rectangles = new ArrayList<>();
        triangles = new ArrayList<>();
        initPolygons();
    }
    
    /**
     * Initializes sample polygons of each type
     * Creates multiple instances with different dimensions
     */
    private void initPolygons() {
        // Sample polygons
        
        circles.add(new Circle(5));
        circles.add(new Circle(7));
        
        squares.add(new Square(4));
        squares.add(new Square(6));
        
        rectangles.add(new Rectangle(4, 6));
        rectangles.add(new Rectangle(5, 8));
        
        triangles.add(new Triangle(5, 4, 4, 4));
        triangles.add(new Triangle(6, 5, 5, 5));
    }
    
    /**
     * Returns a list of polygons of the specified type
     * @param type The type of polygon to return ("circle", "square", etc.)
     * @return List of polygons of the specified type
     */
    public List<PolygonInt> getPolygonsByType(String type) {
        switch(type.toLowerCase()) {
            case "circle": return circles;
            case "square": return squares;
            case "rectangle": return rectangles;
            case "triangle": return triangles;
            default: return new ArrayList<>();
        }
    }
    
    /**
     * Calculates the total area of two polygons
     * @param poly1 First polygon
     * @param poly2 Second polygon
     * @return Sum of the areas of both polygons
     */
    public int calculateTotalArea(PolygonInt poly1, PolygonInt poly2) {
        return poly1.getArea() + poly2.getArea();
    }
    
    /**
     * Calculates the total perimeter of two polygons
     * @param poly1 First polygon
     * @param poly2 Second polygon
     * @return Sum of the perimeters of both polygons
     */
    public int calculateTotalPerimeter(PolygonInt poly1, PolygonInt poly2) {
        return poly1.getPerimeter() + poly2.getPerimeter();
    }
}
